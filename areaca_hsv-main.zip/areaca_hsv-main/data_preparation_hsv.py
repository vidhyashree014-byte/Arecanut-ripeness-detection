import os
import numpy as np
import cv2
from sklearn.model_selection import train_test_split

# Paths to the augmented datasets
RIPE_PATH = 'augmented_dataset/Ripe'
UNRIPE_PATH = 'augmented_dataset/Unripe'

# Image size (resize for uniformity)
IMG_SIZE = 100

def load_images_and_labels():
    X = []
    y = []

    # Load ripe images
    for filename in os.listdir(RIPE_PATH):
        img_path = os.path.join(RIPE_PATH, filename)
        img = cv2.imread(img_path)
        if img is not None:
            img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # Convert to HSV
            img_resized = cv2.resize(img_hsv, (IMG_SIZE, IMG_SIZE))
            X.append(img_resized)
            y.append(1)  # Ripe label = 1

    # Load unripe images
    for filename in os.listdir(UNRIPE_PATH):
        img_path = os.path.join(UNRIPE_PATH, filename)
        img = cv2.imread(img_path)
        if img is not None:
            img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # Convert to HSV
            img_resized = cv2.resize(img_hsv, (IMG_SIZE, IMG_SIZE))
            X.append(img_resized)
            y.append(0)  # Unripe label = 0

    return np.array(X), np.array(y)

def main():
    # Load images and labels
    X, y = load_images_and_labels()
    print("Dataset loaded successfully.")
    print(f"Total images: {len(X)}, Labels: {len(y)}")

    # Normalize data (scale HSV values)
    X = X / 255.0

    # Split dataset into training and testing
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Save datasets
    os.makedirs('data', exist_ok=True)
    np.save('data/X_train.npy', X_train)
    np.save('data/X_test.npy', X_test)
    np.save('data/y_train.npy', y_train)
    np.save('data/y_test.npy', y_test)

    print("Data preprocessing complete. Saved to 'data/' directory.")

if __name__ == "__main__":
    main()

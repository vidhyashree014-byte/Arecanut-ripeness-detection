import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load the trained model
model = load_model('models/arecanut_ripeness_model_hsv.h5')

# Image size (same as training)
IMG_SIZE = 100

def preprocess_image(image_path):
    """
    Preprocess an image:
    - Read the image
    - Convert to HSV color space
    - Resize to match the input size
    - Normalize pixel values
    """
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Image not found at path: {image_path}")
    
    img_hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # Convert to HSV
    img_resized = cv2.resize(img_hsv, (IMG_SIZE, IMG_SIZE))  # Resize to (100, 100)
    img_normalized = img_resized / 255.0  # Normalize to [0, 1]
    return img_normalized

def predict_image(image_path):
    """
    Predict whether an arecanut bunch is ripe or unripe.
    """
    try:
        # Preprocess the image
        img = preprocess_image(image_path)

        # Add batch dimension: (1, 100, 100, 3)
        img_input = np.expand_dims(img, axis=0)

        # Make prediction
        prediction = model.predict(img_input)
        result = 'Ripe' if prediction[0][0] >= 0.5 else 'Unripe'

        print(f"Prediction: {result} (Confidence: {prediction[0][0]:.2f})")

    except ValueError as e:
        print(e)

if __name__ == "__main__":
    # Path to test image
    image_path = r"D:\coding\hsv_new\dataset_dhanesha\Dataset\Un_ripe_Input_Images\IP_UNRIP_078.jpg"  # Replace with the actual test image path
    
    # Predict ripeness
    predict_image(image_path)
